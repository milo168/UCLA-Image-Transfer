#include <sys/socket.h>
#include <sys/signal.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <math.h>
#include <limits.h>
#include <thread>
#include "fsfolderwatcher.h"

mutex vectorLock;

int main(int argc, char* argv[]){
	//cout << "test";
	int port = 4000;
  	string fileDirectory = ".";
  	
  	if(argc > 2){
  	  	cout << "Invalid input" << "\n";
  	  	return -1;
 	}

 	if(argc == 2){
  	  	fileDirectory = argv[1];
 	}
		
	vector<tuple<string,string>> fileInterests;
	vector<string> directories = getFiles(fileDirectory,fileInterests);
	thread fileWatcherThread(watchDirectory,directories,ref(fileInterests));

  	// create a socket using TCP
  	int socketfd = socket(AF_INET,SOCK_STREAM,0);
  	if(socketfd == -1){
   	 	cout << "Bad socket" << "\n";
   	 	close(socketfd);
   	 	return -1;
  	}

  	// allow others to reuse the address
  	int yes = 1;
  	if (setsockopt(socketfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) {
  	  	cout << "Error setting socket option" << "\n";
  	  	return -1;
  	}

  	// bind address to socket
  	//struct hostent *he = gethostbyname("127.0.0.1");
  	struct sockaddr_in addr;
  	addr.sin_family = AF_INET;
  	addr.sin_port = htons(port);     // short, network byte order
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
  	//memcpy(&addr.sin_addr,he->h_addr_list[0],he->h_length);
	memset(addr.sin_zero, '\0', sizeof(addr.sin_zero));

  	if (::bind(socketfd, (struct sockaddr*)&addr, sizeof(addr)) == -1) {
   	 	cout << "Could not bind to socket" << "\n";
   	 	cout << strerror(errno) << "\n";
  	 	return -1;
  	}
	listen(socketfd,5);
	sockaddr_in client;
	socklen_t clientLength = sizeof(client);
	bool flag = true;	
	signal(SIGPIPE,SIG_IGN);

	while(true){
		//Listen for client
		int clientSocket = accept(socketfd,(struct sockaddr*) &client, &clientLength);
		if(clientSocket < 0){
			cout << strerror(errno) << "\n";
			//return -1;
			close(clientSocket);
			continue;
		}
		cout << "connected " << "\n";

		//Get buffer size for control flow
		int bufferSize = 0;
		char bufferSizeArray[4];
		char receive;
		int left = 0;
		while(left < 4 ){
			if(recv(clientSocket,&receive,1,0) < 0){
				cout << strerror(errno) << "\n";
				//return -1;
				close(clientSocket);
				continue;
			}	

			bufferSizeArray[left]= receive;
			left++;
		}
		
		bufferSize = (bufferSizeArray[3] << 24 | bufferSizeArray[2] << 16 | bufferSizeArray[1] << 8 | bufferSizeArray[0]);
		bufferSize = ntohl(bufferSize);
		cout << "Flow control limit: " << bufferSize << "\n";

		//Send number of files to be transmitted then send files
		/*int32_t numFiles = htonl(fileInterests.size());
		char *numData = (char*)&numFiles;
		left = sizeof(numFiles);
		while(left > 0){
			int bytesWritten = 0;
			if((bytesWritten = write(clientSocket,numData,left)) < 0){
				cout << strerror(errno) << "\n";
				//return -1;
				close(clientSocket);
				continue;
			}
			numData += bytesWritten;
			left -= bytesWritten;
		}*/

		int count = 0;
		//while(fileInterests->size() != 0){
		while(true){
		//for(unsigned int i = 0; i < fileInterests.size(); i++){
			vectorLock.lock();
			if(fileInterests.size() != 0){
				//cout << count << "\n";
				vectorLock.unlock();
				char message[5];
				left = 0;


				vectorLock.lock();
				if(count % bufferSize == 0 && fileInterests.size()-1 != 0 && count != 0){
					vectorLock.unlock();
					while(left < 4 ){
						if(recv(clientSocket,&receive,1,0) <= 0){
							cout << strerror(errno) << "\n";
							flag = false;
							break;
							//return -1;
						}
						message[left]= receive;
						left++;
					}
				
					if(flag == false){
						break;
					}

					message[4] = '\0';
					if(strcmp(message,"send") != 0){
						//count--;
						continue;
					}
				}else{
					vectorLock.unlock();
				}
			
				//cout << message << "\n";
				//Send file name length first then send file name
				vectorLock.lock();
				int32_t fileNameLength = htonl(get<1>(fileInterests.at(0)).length());
				vectorLock.unlock();
				char *data = (char *)&fileNameLength;
				left = sizeof(fileNameLength);
					while(left > 0){
					int bytesWritten = 0;
					if((bytesWritten = write(clientSocket,data,left)) < 0){
						cout << strerror(errno) << "\n";
						flag = false;
						break;
						//return -1;
					}
					data += bytesWritten;
					left -= bytesWritten;
				}
				if(flag == false){
					break;
				}	
			
				vectorLock.lock();
				left = get<1>(fileInterests.at(0)).length();
				const char* ptrName = get<1>(fileInterests.at(0)).c_str();
				vectorLock.unlock();
				while(left > 0){
					int bytesWritten = 0;
					if((bytesWritten = write(clientSocket,ptrName,left)) < 0){
						cout << strerror(errno) << "\n";
						flag = false;
						break;
						//return -1;
					}
					ptrName += bytesWritten;
					left -= bytesWritten;
				}

				if(flag == false){
					break;
				}
				//Send file length then send file
				vectorLock.lock();
				ifstream file(get<0>(fileInterests.at(0)), ios::in | ios::binary);
				vectorLock.unlock();
				//This only checks if file isnt deleted before sending
				if(file.is_open() == false){
					break;
				}

				file.seekg(0, file.end);
				int fileSize = file.tellg();
				int32_t sendFileSize = htonl(fileSize);
				file.seekg(0, file.beg);
			
				data = (char *)&sendFileSize;
				left = sizeof(sendFileSize);

				while(left > 0){
					int bytesWritten = 0;
					if((bytesWritten = write(clientSocket,data,left)) < 0){
						cout << strerror(errno) << "\n";
						flag = false;
						break;
						//return -1;
					}
					data += bytesWritten;
					left -= bytesWritten;
				}
				if(flag == false){
					break;
				}

				char buffer[1024];
				memset(buffer,0,sizeof(buffer));
				char *ptr = buffer;
				//cout << fileInterests.at(i).second << " " << fileSize << "\n";
				while((int)fileSize > 0){
					file.read(buffer,sizeof(buffer));
					int bytesPlaced = file.gcount();
					fileSize -= bytesPlaced;
				
					while(bytesPlaced > 0){
						int bytesWritten = 0;
						if((bytesWritten = write(clientSocket,ptr,bytesPlaced)) < 0){
							cout << strerror(errno) << "\n";
							flag = false;
							break;
							//return -1;
						}
						ptr += bytesWritten;
						bytesPlaced -= bytesWritten;
					}
					if(flag == false){
						break;
					}

					ptr = buffer;
					memset(buffer,0,sizeof(buffer));
					//cout << fileSize << " " << bytesPlaced << "\n";
				}
				if(flag == false){
					break;
				}
				file.close();
				count++;
				vectorLock.lock();
				unlink(get<0>(fileInterests.at(0)).c_str());
				fileInterests.erase(fileInterests.begin());
				vectorLock.unlock();
			}else{
				vectorLock.unlock();
			}
		}
		flag = true;
		close(clientSocket);
	}
	//break;
	close(socketfd);
	fileWatcherThread.join();
	return 0;
}
