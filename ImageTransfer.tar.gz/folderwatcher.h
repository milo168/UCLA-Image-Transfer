#include <iostream>
#include <algorithm>
#include <tuple>
#include <vector>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <string.h>

using namespace std;

vector<tuple<string,string>> getFiles(string fileDirectory);
bool sortByName(const tuple<string,string> &lhs, const tuple<string,string> &rhs);
