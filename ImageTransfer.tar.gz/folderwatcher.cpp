#include "folderwatcher.h"

vector<string> getFiles(string fileDirectory,vector<tuple<string,string>> &fileInterests){
	DIR *directory = NULL;
	directory = opendir(fileDirectory.c_str());
	dirent *file = NULL;
	vector<DIR*> directoryInterests;
	vector<string> directoryWatch;
	struct stat statbuf;

	if(directory == NULL){
		cout << strerror(errno) << "\n";
		exit(EXIT_FAILURE);
	}

	directoryInterests.push_back(directory);
	if(chdir(fileDirectory.c_str()) != 0){
		cout << strerror(errno) << "\n";
		exit(EXIT_FAILURE);
	}

	string exePath(get_current_dir_name());
	while(directoryInterests.size() != 0){
		//Check for PNG
		//Also DFS traversal
		while((file = readdir(directoryInterests.at(directoryInterests.size()-1))) != NULL){
			lstat(file->d_name,&statbuf);
			//Regular File
			if(S_ISREG(statbuf.st_mode) != 0){
				string fileName(file->d_name);
				char signature[8];
				ifstream check(fileName, ios::in|ios::binary);
				check.read(signature,sizeof(signature));

				if(signature[0] == '\x89' && signature[1] == '\x50' && signature[2] == '\x4e' && signature[3] == '\x47' 
				&& signature[4] == '\x0d' && signature[5] == '\x0a' && signature[6] == '\x1a' && signature[7] == '\x0a'){
					//cout << fileName << "\n";
					char bufferName[PATH_MAX + 1];
					if(realpath(file->d_name,bufferName) != NULL){
						string absolutePath(bufferName);
						string relativePath(file->d_name);
						//cout << relativePath << "\n";
						fileInterests.push_back(make_tuple(absolutePath,relativePath));
						//cout << ctime(&statbuf.st_mtime) << "\n";
					}
				}
				check.close();
			//Directory
			}else if(S_ISDIR(statbuf.st_mode) != 0 && file->d_name[0] != '.' && file->d_name[1] != '.' && strcmp(file->d_name,"Receive Folder") != 0){
				//cout << file->d_name << "\n";
				string dirName(file->d_name);
				DIR *directoryInterest = NULL;
				directoryInterest = opendir(file->d_name);

				if(directoryInterest != NULL){
					directoryInterests.push_back(directoryInterest);
					directoryWatch.push_back(string(get_current_dir_name()) + "/" + string(file->d_name));
					if(chdir(file->d_name) != 0){
						cout << strerror(errno) << "\n";
						exit(EXIT_FAILURE);
					}
				}
			}
		}
	
		if(directoryInterests.size() != 1){
			if(chdir("..") != 0){
				cout << strerror(errno) << "\n";
				exit(EXIT_FAILURE);
			}
		}
		
		closedir(directoryInterests.at(directoryInterests.size()-1));
		directoryInterests.pop_back();
	}
	directoryWatch.push_back(exePath);
	/*if(chdir(exePath.c_str()) != 0){
		cout << strerror(errno) << "\n";
		exit(EXIT_FAILURE);
	}*/

	//cout << get_current_dir_name() << "\n";
	
	//sort file
	sort(fileInterests.begin(),fileInterests.end(),sortByName);
	/*for(unsigned int i = 0; i < fileInterests->size(); i++){
		cout << get<0>(fileInterests->at(i)) << "\n";
	}*/

	return directoryWatch;
}

void watchDirectory(vector<string> directoryWatch, vector<tuple<string,string>> &fileInterests){
	int fd;
	int *wd;
	vector<tuple<int,string>> watchAssociation;
	fd = inotify_init();

	if(fd < 0){
		cout << strerror(errno) << "\n";
		exit(EXIT_FAILURE);
	}
	wd = new int[directoryWatch.size()];
	for(unsigned int i = 0; i < directoryWatch.size(); i++){
		//cout << directoryWatch.at(i) << "\n";
		wd[i] = inotify_add_watch(fd,directoryWatch.at(i).c_str(),/*IN_CREATE | IN_DELETE | IN_MOVED_FROM | IN_DELETE_SELF |*/ IN_CLOSE_WRITE);
		watchAssociation.push_back(make_tuple(wd[i],directoryWatch.at(i)));
	}

	while(1){
		int i = 0;
		int length;
		char buffer[1024 *(sizeof(struct inotify_event) + 16)];
		length = read (fd,buffer,1024 *(sizeof(struct inotify_event) + 16));

		if(length < 0){
			cout << strerror(errno) << "\n";
			exit(EXIT_FAILURE);
		}

		while(i < length){
			struct inotify_event *event = (struct inotify_event *) &buffer[i];
			/*if(event -> mask & IN_DELETE_SELF){
				for(unsigned int i = 0; i < watchAssociation.size(); i++){
					if(event->wd == get<0>(watchAssociation.at(i))){
						cout << "Deleted myself " << get<1>(watchAssociation.at(i)) << "\n";
					}
				}
			}else*//* if(event -> mask & IN_CREATE){
				for(unsigned int i = 0; i < watchAssociation.size(); i++){
					if(event->wd == get<0>(watchAssociation.at(i))){
						cout << "Something was created " << get<1>(watchAssociation.at(i)) << "\n";
						cout << event->name << "\n";
					}
				}
			}else*/ if(event-> mask & IN_CLOSE_WRITE){
				for(unsigned int i = 0; i < watchAssociation.size(); i++){
					if(event->wd == get<0>(watchAssociation.at(i))){
						//cout << "Something was done writing " << get<1>(watchAssociation.at(i)) << "\n";
						//cout << event->name << "\n";

						dirent *file = NULL;
						DIR *directory = NULL;

						directory = opendir(get<1>(watchAssociation.at(i)).c_str());
						if(chdir(get<1>(watchAssociation.at(i)).c_str()) != 0){
							cout << strerror(errno) << "\n";
							exit(EXIT_FAILURE);
						}

						vectorLock.lock();
						while((file = readdir(directory)) != NULL){
						
							struct stat statbuf;
							lstat(file->d_name,&statbuf);
							string fileName(file->d_name);
							string eventName(event->name);
							//cout << " " << fileName << " " << eventName << "\n";
							//Regular File
							if(S_ISREG(statbuf.st_mode) != 0 && eventName == fileName){
								char signature[8];
								memset(signature,0,8);
								ifstream check(fileName, ios::in|ios::binary);
								check.read(signature,sizeof(signature));

								if(signature[0] == '\x89' && signature[1] == '\x50' && signature[2] == '\x4e' && signature[3] == '\x47' 
								&& signature[4] == '\x0d' && signature[5] == '\x0a' && signature[6] == '\x1a' && signature[7] == '\x0a'){
									//cout << fileName << "\n";
									char bufferName[PATH_MAX + 1];
									if(realpath(file->d_name,bufferName) != NULL){
										string absolutePath(bufferName);
										string relativePath(file->d_name);
										//cout << relativePath << "\n";
										fileInterests.push_back(make_tuple(absolutePath,relativePath));
										//cout << fileInterests.size() << "\n";
										//cout << "added "<< absolutePath << "\n";
										//cout << ctime(&statbuf.st_mtime) << "\n";
									}
								}	
							check.close();
							}
						}

						if(chdir("..") != 0){
							cout << strerror(errno) << "\n";
							exit(EXIT_FAILURE);
						}
						closedir(directory);
						sort(fileInterests.begin(),fileInterests.end(),sortByName);
						vectorLock.unlock();
					}
				}
			}/*else if(event ->mask & IN_DELETE){
				for(unsigned int i = 0; i < watchAssociation.size(); i++){
					if(event->wd == get<0>(watchAssociation.at(i))){
						cout << "Something was deleted " << get<1>(watchAssociation.at(i)) << "\n";
						cout << event->name << "\n";
					}
				}
			}else if(event ->mask & IN_MOVED_FROM){
				for(unsigned int i = 0; i < watchAssociation.size(); i++){
					if(event->wd == get<0>(watchAssociation.at(i))){
						cout << "Something was moved " << get<1>(watchAssociation.at(i)) << "\n";
						cout << event->name << "\n";
					}
				}
			}*/
			i += sizeof(struct inotify_event) + event->len;
		}
	}

	cout << "Finished" << "\n";
	for(unsigned int i = 0; i < directoryWatch.size(); i++){
		inotify_rm_watch(fd,wd[i]);
	}
	delete wd;
	close(fd);
}

bool sortByName(const tuple<string,string> &lhs, const tuple<string,string> &rhs){
	string padLeft = get<0>(lhs).substr(0,get<0>(lhs).length()-4);
	string padRight = get<0>(rhs).substr(0,get<0>(rhs).length()-4);
	int padLeftLength = padLeft.length();
	int padRightLength = padRight.length();

	for(int i = 0; i < padLeftLength; i++){
		padLeft[i] = tolower(padLeft[i]);
	}

	for(int i = 0; i < padRightLength; i++){
		padRight[i] = tolower(padRight[i]);
	}

	if(padLeftLength < padRightLength){
		string number;
		for(int i = padLeftLength-1; i > 0; i--){
			if(isdigit(padLeft[i]) == false){
				number = padLeft.substr(i+1,padLeftLength-i);
				padLeft = padLeft.substr(0,i+1);
				for(int j =0; j < padRightLength - padLeftLength; j++){
					padLeft += "0";
				}
				padLeft += number;
				break;
			}
		}
	}else if(padLeftLength > padRightLength){
		string number;
		for(int i = padRightLength-1; i > 0; i--){
			if(isdigit(padRight[i]) == false){
				number = padRight.substr(i+1,padRightLength-i);
				padRight = padRight.substr(0,i+1);
				for(int j =0; j < padLeftLength - padRightLength; j++){
					padRight += "0";
				}
				padRight += number;
				break;
			}
		}
	}
	//cout<< padLeft << " "<< padRight << "\n";
	return lexicographical_compare(padLeft.c_str(),padLeft.c_str()+padLeft.length(),padRight.c_str(),padRight.c_str() + padRight.length());
}
