#include <iostream>
#include <algorithm>
#include <tuple>
#include <vector>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <string.h>
#include <sys/inotify.h>
#include <mutex>

using namespace std;

vector<string> getFiles(string fileDirectory,vector<tuple<string,string>> &fileInterests);
void watchDirectory(vector<string> directoryWatch, vector<tuple<string,string>> &fileInterests);
bool sortByName(const tuple<string,string> &lhs, const tuple<string,string> &rhs);

extern mutex vectorLock;
