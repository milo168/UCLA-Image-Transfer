#include <string>
#include <string.h>
#include <thread>
#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <netdb.h>
#include <fstream>
#include <sys/fcntl.h>
#include <stdint.h>
#include <limits.h>

using namespace std;

int main(int argc, char* argv[]){ 
  	string host = "10.0.0.1";
  	string port = "4000";

  	if(argc != 3){
    		cout << "Invalid input" << "\n";
    		return -1;
  	}

  	if(argc == 3){
    		host = argv[1];
    		port = argv[2];
  	}

  	int socketfd;
  	struct addrinfo hints, *servinfo, *p;

	memset(&hints,0,sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;

	if(getaddrinfo(host.c_str(),port.c_str(),&hints,&servinfo) != 0){
		cout << strerror(errno) << "\n";
		return -1;	
	}
  	
  	struct sockaddr serverAddress;
	for(p = servinfo; p != NULL; p = p->ai_next){
		if((socketfd = socket(p->ai_family,p->ai_socktype,p->ai_protocol)) == -1){
			continue;
		}
		
		if(connect(socketfd,p->ai_addr,p->ai_addrlen) == -1){
			close(socketfd);
			cout << strerror(errno);
			continue;
		}
		break;
	}

	if(p == NULL){
		cout << "Failed to connect: " << host << "\n";
		return -1;
	}
	
	//memcpy(&serverAddress,p->ai_addr,p->ai_addrlen);
	//socklen_t servAddrSize = sizeof(serverAddress);
	freeaddrinfo(servinfo);

	while(1){
		//Create folder for receiving
		struct stat st;
		if(stat("./Receive Folder",&st) == -1){
			mkdir("./Receive Folder", 0700);
		}

		//Start timer
		time_t t = time(NULL);
		struct timeval t1, t2;
		double elapsedTime;
		char *timeString = ctime(&t);
		gettimeofday(&t1,NULL);
		cout << "Start: " << timeString;
		
		//Read number of files to receive
		int32_t value;
		char *data = (char *)&value;
		int left = sizeof(value);
		
		while(left > 0){
			int bytesRead = 0;
			if((bytesRead = read(socketfd,data,left)) < 0 ){
				cout << strerror(errno) << "\n";
				return -1;
			}
			data += bytesRead;
			left -= bytesRead;
		}
		value = ntohl(value);
		
		for(int i = 0; i < value; i++){
			//Read number of length of file name
			int32_t fileNameLength;
			data = (char *)&fileNameLength;
			left = sizeof(fileNameLength);

			while(left > 0){
				int bytesRead = 0;
				if((bytesRead = read(socketfd,data,left)) < 0 ){
					cout << strerror(errno) << "\n";
					return -1;
				}
				data += bytesRead;
				left -= bytesRead;
			}

			fileNameLength = ntohl(fileNameLength);
			//Get file name
			char fileName[PATH_MAX + 1];
			memset(fileName,0,sizeof(fileName));
			data = fileName;
			while(fileNameLength > 0){
				int bytesRead = 0;
				if((bytesRead = read(socketfd,data,fileNameLength)) < 0){
					cout << strerror(errno) << "\n";
					return -1;
				}
				data += bytesRead;
				fileNameLength -= bytesRead;
			}

			ofstream saveFile;
			string path = "./Receive Folder/";
			string buf(fileName);
			string checkPath = path + buf;
			int copy = 1;

			while(stat(checkPath.c_str(),&st) == 0){
				checkPath = path + "(" + to_string(copy) + ") " + buf;
				//cout << checkPath << "\n";
				copy++;
				
			}
			//cout << checkPath << "\n";
			saveFile.open(checkPath.c_str(),ios::out | ios::binary);

			//Get file size
			int32_t fileSize;
			data = (char *)&fileSize;
			left = sizeof(fileSize);

			while(left > 0){
				int bytesRead = 0;
				if((bytesRead = read(socketfd,data,left)) < 0 ){
					cout << strerror(errno) << "\n";
					return -1;
				}
				data += bytesRead;
				left -= bytesRead;
			}

			fileSize = ntohl(fileSize);
			//cout << fileName << " " << fileSize << "\n";
			//Read file
			char buffer[1024];
			while(fileSize > 0){
				int bytesRead = 0;
				if(fileSize > 1024){
					if((bytesRead = read(socketfd,buffer,sizeof(buffer))) < 0){
						cout << strerror(errno) << "\n";
						return -1;
					}
				}else{
					if((bytesRead = read(socketfd,buffer,fileSize)) < 0){
						cout << strerror(errno) << "\n";
						return -1;
					}
				}
				saveFile.write(buffer,bytesRead);
				saveFile.flush();
				fileSize -= bytesRead;
				memset(buffer,0,sizeof(buffer));
			}
			saveFile.close();
		}
		timeString = ctime(&t);
		gettimeofday(&t2,NULL);
		elapsedTime = (t2.tv_sec - t1.tv_sec) * 1000;
		elapsedTime += (t2.tv_usec - t1.tv_usec)/1000;
		cout << "End: " << timeString;
		cout << "Transferred " << value << " files in ms: " << elapsedTime << "\n";
		break;
	}

  	close(socketfd);
  	return 0;
}
