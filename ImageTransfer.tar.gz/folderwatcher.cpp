#include "folderwatcher.h"

vector<tuple<string,string>> getFiles(string fileDirectory){
	DIR *directory = NULL;
	directory = opendir(fileDirectory.c_str());
	dirent *file = NULL;
	vector<tuple<string,string>> fileInterests;
	vector<DIR*> directoryInterests;
	struct stat statbuf;

	if(directory == NULL){
		cout << strerror(errno) << "\n";
		exit(EXIT_FAILURE);
	}

	directoryInterests.push_back(directory);
	if(chdir(fileDirectory.c_str()) != 0){
		cout << strerror(errno) << "\n";
		exit(EXIT_FAILURE);
	}
	while(directoryInterests.size() != 0){
		//Check for PNG
		//Also DFS traversal
		while((file = readdir(directoryInterests.at(directoryInterests.size()-1))) != NULL){
			lstat(file->d_name,&statbuf);
			//Regular File
			if(S_ISREG(statbuf.st_mode) != 0){
				string fileName(file->d_name);
				char signature[8];
				ifstream check(fileName, ios::in|ios::binary);
				check.read(signature,sizeof(signature));

				if(signature[0] == '\x89' && signature[1] == '\x50' && signature[2] == '\x4e' && signature[3] == '\x47' 
				&& signature[4] == '\x0d' && signature[5] == '\x0a' && signature[6] == '\x1a' && signature[7] == '\x0a'){
					//cout << fileName << "\n";
					char bufferName[PATH_MAX + 1];
					if(realpath(file->d_name,bufferName) != NULL){
						string absolutePath(bufferName);
						string relativePath(file->d_name);
						//cout << relativePath << "\n";
						fileInterests.push_back(make_pair(absolutePath,relativePath));
						//cout << ctime(&statbuf.st_mtime) << "\n";
					}
				}
				check.close();
			//Directory
			}else if(S_ISDIR(statbuf.st_mode) != 0 && file->d_name[0] != '.' && file->d_name[1] != '.' && strcmp(file->d_name,"Receive Folder") != 0){
				//cout << file->d_name << "\n";
				string dirName(file->d_name);
				DIR *directoryInterest = NULL;
				directoryInterest = opendir(file->d_name);

				if(directoryInterest != NULL){
					directoryInterests.push_back(directoryInterest);
					if(chdir(file->d_name) != 0){
						cout << strerror(errno) << "\n";
						exit(EXIT_FAILURE);
					}
				}
			}
		}

		closedir(directoryInterests.at(directoryInterests.size()-1));
		directoryInterests.pop_back();

		if(chdir("..") != 0){
			cout << strerror(errno) << "\n";
			exit(EXIT_FAILURE);
		}
	}
	//sort file
	sort(fileInterests.begin(),fileInterests.end(),sortByName);
	for(int i = 0; i < fileInterests.size(); i++){
		cout << get<0>(fileInterests.at(i)) << "\n";
	}
	return fileInterests;
}

bool sortByName(const tuple<string,string> &lhs, const tuple<string,string> &rhs){
	string padLeft = get<0>(lhs).substr(0,get<0>(lhs).length()-4);
	string padRight = get<0>(rhs).substr(0,get<0>(rhs).length()-4);
	int padLeftLength = padLeft.length();
	int padRightLength = padRight.length();

	for(int i = 0; i < padLeftLength; i++){
		padLeft[i] = tolower(padLeft[i]);
	}

	for(int i = 0; i < padRightLength; i++){
		padRight[i] = tolower(padRight[i]);
	}

	if(padLeftLength < padRightLength){
		string number;
		for(int i = padLeftLength-1; i > 0; i--){
			if(isdigit(padLeft[i]) == false){
				number = padLeft.substr(i+1,padLeftLength-i);
				padLeft = padLeft.substr(0,i+1);
				for(int j =0; j < padRightLength - padLeftLength; j++){
					padLeft += "0";
				}
				padLeft += number;
				break;
			}
		}
	}else if(padLeftLength > padRightLength){
		string number;
		for(int i = padRightLength-1; i > 0; i--){
			if(isdigit(padRight[i]) == false){
				number = padRight.substr(i+1,padRightLength-i);
				padRight = padRight.substr(0,i+1);
				for(int j =0; j < padLeftLength - padRightLength; j++){
					padRight += "0";
				}
				padRight += number;
				break;
			}
		}
	}
	//cout<< padLeft << " "<< padRight << "\n";
	return lexicographical_compare(padLeft.c_str(),padLeft.c_str()+padLeft.length(),padRight.c_str(),padRight.c_str() + padRight.length());
}
