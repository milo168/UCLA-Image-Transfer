#include <thread>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/signal.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <math.h>
#include <limits.h>
#include "folderwatcher.h"

int main(int argc, char* argv[]){
	//cout << "test";
	int port = 4000;
  	string fileDirectory = ".";
  	
  	if(argc > 2){
  	  	cout << "Invalid input" << "\n";
  	  	return -1;
 	}

 	if(argc == 2){
  	  	fileDirectory = argv[1];
 	}
	
	vector<tuple<string,string>> fileInterests = getFiles(fileDirectory);

  	// create a socket using TCP
  	int socketfd = socket(AF_INET,SOCK_STREAM,0);
  	if(socketfd == -1){
   	 	cout << "Bad socket" << "\n";
   	 	close(socketfd);
   	 	return -1;
  	}

  	// allow others to reuse the address
  	int yes = 1;
  	if (setsockopt(socketfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) {
  	  	cout << "Error setting socket option" << "\n";
  	  	return -1;
  	}

  	// bind address to socket
  	//struct hostent *he = gethostbyname("127.0.0.1");
  	struct sockaddr_in addr;
  	addr.sin_family = AF_INET;
  	addr.sin_port = htons(port);     // short, network byte order
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
  	//memcpy(&addr.sin_addr,he->h_addr_list[0],he->h_length);
	memset(addr.sin_zero, '\0', sizeof(addr.sin_zero));

  	if (::bind(socketfd, (struct sockaddr*)&addr, sizeof(addr)) == -1) {
   	 	cout << "Could not bind to socket" << "\n";
   	 	cout << strerror(errno) << "\n";
  	 	return -1;
  	}
	listen(socketfd,5);
	sockaddr_in client;
	socklen_t clientLength = sizeof(client);
	bool flag = true;	
	signal(SIGPIPE,SIG_IGN);

	while(1){
		int clientSocket = accept(socketfd,(struct sockaddr*) &client, &clientLength);
		if(clientSocket < 0){
			cout << strerror(errno) << "\n";
			flag = false;
			//return -1;
		}
		cout << "connected " << "\n";
		//Get buffer size for control flow
		int bufferSize = 0;
		char bufferSizeArray[4];
		char receive;
		int left = 0;
		while(left < 4 ){
			if(recv(clientSocket,&receive,1,0) < 0){
				cout << strerror(errno) << "\n";
				flag = false;
				break;
				//return -1;
			}

			bufferSizeArray[left]= receive;
			left++;
		}

		if(flag == false){
			flag = true;
			continue;
		}
		
		bufferSize = (bufferSizeArray[3] << 24 | bufferSizeArray[2] << 16 | bufferSizeArray[1] << 8 | bufferSizeArray[0]);
		bufferSize = ntohl(bufferSize);
		cout << "Flow control limit: " << bufferSize << "\n";

		//Send number of files to be transmitted then send files
		int32_t numFiles = htonl(fileInterests.size());
		char *numData = (char*)&numFiles;
		left = sizeof(numFiles);
		while(left > 0){
			int bytesWritten = 0;
			if((bytesWritten = write(clientSocket,numData,left)) < 0){
				cout << strerror(errno) << "\n";
				flag = false;
				break;
				//return -1;
			}
			numData += bytesWritten;
			left -= bytesWritten;
		}

		if(flag == false){
			flag = true;
			continue;
		}

		int count = 0;
		while(fileInterests.size() != 0){
		//for(unsigned int i = 0; i < fileInterests.size(); i++){
			char message[5];
			left = 0;

			if(count % bufferSize == 0 && fileInterests.size()-1 != 0 && count != 0){
				while(left < 4 ){
					if(recv(clientSocket,&receive,1,0) <= 0){
						cout << strerror(errno) << "\n";
						flag = false;
						break;
						//return -1;
					}
					message[left]= receive;
					left++;
				}
				
				if(flag == false){
					break;
				}

				message[4] = '\0';
				if(strcmp(message,"send") != 0){
					count--;
					continue;
				}
			}
			
			//cout << message << "\n";
			//Send file name length first then send file name
			int32_t fileNameLength = htonl(get<1>(fileInterests.at(0)).length());
			char *data = (char *)&fileNameLength;
			left = sizeof(fileNameLength);
			while(left > 0){
				int bytesWritten = 0;
				if((bytesWritten = write(clientSocket,data,left)) < 0){
					cout << strerror(errno) << "\n";
					flag = false;
					break;
					//return -1;
				}
				data += bytesWritten;
				left -= bytesWritten;
			}
			if(flag == false){
				break;
			}
			
			left = get<1>(fileInterests.at(0)).length();
			const char* ptrName = get<1>(fileInterests.at(0)).c_str();
			while(left > 0){
				int bytesWritten = 0;
				if((bytesWritten = write(clientSocket,ptrName,left)) < 0){
					cout << strerror(errno) << "\n";
					flag = false;
					break;
					//return -1;
				}
				ptrName += bytesWritten;
				left -= bytesWritten;
			}

			if(flag == false){
				break;
			}
			//Send file length then send file
			ifstream file(get<0>(fileInterests.at(0)), ios::in | ios::binary);

			file.seekg(0, file.end);
			int fileSize = file.tellg();
			int32_t sendFileSize = htonl(fileSize);
			file.seekg(0, file.beg);
			
			data = (char *)&sendFileSize;
			left = sizeof(sendFileSize);

			while(left > 0){
				int bytesWritten = 0;
				if((bytesWritten = write(clientSocket,data,left)) < 0){
					cout << strerror(errno) << "\n";
					flag = false;
					break;
					//return -1;
				}
				data += bytesWritten;
				left -= bytesWritten;
			}
			if(flag == false){
				break;
			}

			char buffer[1024];
			memset(buffer,0,sizeof(buffer));
			char *ptr = buffer;
			//cout << fileInterests.at(i).second << " " << fileSize << "\n";
			while((int)fileSize > 0){
				file.read(buffer,sizeof(buffer));
				int bytesPlaced = file.gcount();
				fileSize -= bytesPlaced;
				
				while(bytesPlaced > 0){
					int bytesWritten = 0;
					if((bytesWritten = write(clientSocket,ptr,bytesPlaced)) < 0){
						cout << strerror(errno) << "\n";
						flag = false;
						break;
						//return -1;
					}
					ptr += bytesWritten;
					bytesPlaced -= bytesWritten;
				}
				if(flag == false){
					break;
				}

				ptr = buffer;
				memset(buffer,0,sizeof(buffer));
				//cout << fileSize << " " << bytesPlaced << "\n";
			}
			if(flag == false){
				break;
			}
			file.close();
			count++;
			unlink(get<0>(fileInterests.at(0)).c_str());
			fileInterests.erase(fileInterests.begin());
		}
		flag = true;
		close(clientSocket);
		//break;
	}


	close(socketfd);
	return 0;
}
