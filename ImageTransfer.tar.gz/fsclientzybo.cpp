#include <thread>
#include <sys/socket.h>
#include <sys/signal.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <netdb.h>
#include "fsfolderwatcher.h"

mutex vectorLock;

int main(int argc, char* argv[]){ 
  	string host = "192.168.56.1";
  	string port = "4000";
	string fileDirectory = ".";

  	if(argc > 3){
    		cout << "Invalid input" << "\n";
    		return -1;
  	}

  	if(argc == 3){
    		host = argv[1];
    		port = argv[2];
  	}

  	int socketfd;
  	struct addrinfo hints, *servinfo, *p;

	memset(&hints,0,sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;

	if(getaddrinfo(host.c_str(),port.c_str(),&hints,&servinfo) != 0){
		cout << strerror(errno) << "\n";
		return -1;	
	}
  	
  	struct sockaddr serverAddress;
	for(p = servinfo; p != NULL; p = p->ai_next){
		if((socketfd = socket(p->ai_family,p->ai_socktype,p->ai_protocol)) == -1){
			continue;
		}
		
		if(connect(socketfd,p->ai_addr,p->ai_addrlen) == -1){
			close(socketfd);
			cout << strerror(errno);
			continue;
		}
		break;
	}

	if(p == NULL){
		cout << "Failed to connect: " << host << "\n";
		return -1;
	}
	
	//memcpy(&serverAddress,p->ai_addr,p->ai_addrlen);
	//socklen_t servAddrSize = sizeof(serverAddress);
	freeaddrinfo(servinfo);

	vector<tuple<string,string>> fileInterests;
	vector<string> directories = getFiles(fileDirectory,fileInterests);
	thread fileWatcherThread(watchDirectory,directories,ref(fileInterests));

	bool flag = true;	
	signal(SIGPIPE,SIG_IGN);

	cout << "connected " << "\n";
	//Get buffer size for control flow
	int bufferSize = 0;
	char bufferSizeArray[4];
	char receive;
	int left = 0;
	while(left < 4 ){
		if(recv(socketfd,&receive,1,0) < 0){
			cout << strerror(errno) << "\n";
			//return -1;
			close(socketfd);
			continue;
		}	
			bufferSizeArray[left]= receive;
		left++;
	}
	
	bufferSize = (bufferSizeArray[3] << 24 | bufferSizeArray[2] << 16 | bufferSizeArray[1] << 8 | bufferSizeArray[0]);
	bufferSize = ntohl(bufferSize);
	cout << "Flow control limit: " << bufferSize << "\n";

	//Send number of files to be transmitted then send files
	/*int32_t numFiles = htonl(fileInterests.size());
	char *numData = (char*)&numFiles;
	left = sizeof(numFiles);
	while(left > 0){
		int bytesWritten = 0;
		if((bytesWritten = write(socketfd,numData,left)) < 0){
			cout << strerror(errno) << "\n";
			//return -1;
			close(socketfd);	
			continue;
		}
		numData += bytesWritten;
		left -= bytesWritten;
	}*/

	int count = 0;
	//while(fileInterests->size() != 0){
	while(true){
	//for(unsigned int i = 0; i < fileInterests.size(); i++){
		vectorLock.lock();
		if(fileInterests.size() != 0){
			//cout << count << "\n";
			vectorLock.unlock();
			char message[5];
			left = 0;


			vectorLock.lock();
			if(count % bufferSize == 0 && fileInterests.size()-1 != 0 && count != 0){
				vectorLock.unlock();
				while(left < 4 ){
					if(recv(socketfd,&receive,1,0) <= 0){
						cout << strerror(errno) << "\n";
						flag = false;
						break;
						//return -1;
					}
					message[left]= receive;
					left++;
				}
				
				if(flag == false){
					break;
				}

				message[4] = '\0';
				if(strcmp(message,"send") != 0){
					//count--;
					continue;
				}
			}else{
				vectorLock.unlock();
			}
			
			//cout << message << "\n";
			//Send file name length first then send file name
			vectorLock.lock();
			int32_t fileNameLength = htonl(get<1>(fileInterests.at(0)).length());
			vectorLock.unlock();
			char *data = (char *)&fileNameLength;
			left = sizeof(fileNameLength);
			while(left > 0){
				int bytesWritten = 0;
				if((bytesWritten = write(socketfd,data,left)) < 0){
					cout << strerror(errno) << "\n";
					flag = false;
					break;
					//return -1;
				}
				data += bytesWritten;
				left -= bytesWritten;
			}
			if(flag == false){
				break;
			}	
			
			vectorLock.lock();
			left = get<1>(fileInterests.at(0)).length();
			const char* ptrName = get<1>(fileInterests.at(0)).c_str();
			vectorLock.unlock();
			while(left > 0){
				int bytesWritten = 0;
				if((bytesWritten = write(socketfd,ptrName,left)) < 0){
					cout << strerror(errno) << "\n";
					flag = false;
					break;
					//return -1;
				}
				ptrName += bytesWritten;
				left -= bytesWritten;
			}

			if(flag == false){
				break;
			}
			//Send file length then send file
			vectorLock.lock();
			ifstream file(get<0>(fileInterests.at(0)), ios::in | ios::binary);
			vectorLock.unlock();
			//This only checks if file isnt deleted before sending
			if(file.is_open() == false){
				break;
			}

			file.seekg(0, file.end);
			int fileSize = file.tellg();
			int32_t sendFileSize = htonl(fileSize);
			file.seekg(0, file.beg);
			
			data = (char *)&sendFileSize;
			left = sizeof(sendFileSize);

			while(left > 0){
				int bytesWritten = 0;
				if((bytesWritten = write(socketfd,data,left)) < 0){
					cout << strerror(errno) << "\n";
					flag = false;
					break;
					//return -1;
				}
				data += bytesWritten;
				left -= bytesWritten;
			}
			if(flag == false){
				break;
			}

			char buffer[1024];
			memset(buffer,0,sizeof(buffer));
			char *ptr = buffer;
			//cout << fileInterests.at(i).second << " " << fileSize << "\n";
			while((int)fileSize > 0){
				file.read(buffer,sizeof(buffer));
				int bytesPlaced = file.gcount();
				fileSize -= bytesPlaced;
				
				while(bytesPlaced > 0){
					int bytesWritten = 0;
					if((bytesWritten = write(socketfd,ptr,bytesPlaced)) < 0){
						cout << strerror(errno) << "\n";
						flag = false;
						break;
						//return -1;
					}
					ptr += bytesWritten;
					bytesPlaced -= bytesWritten;
				}
				if(flag == false){
					break;
				}
				ptr = buffer;
				memset(buffer,0,sizeof(buffer));
				//cout << fileSize << " " << bytesPlaced << "\n";
			}
			if(flag == false){
				break;
			}
			file.close();
			count++;
			vectorLock.lock();
			unlink(get<0>(fileInterests.at(0)).c_str());
			fileInterests.erase(fileInterests.begin());
			vectorLock.unlock();
		}else{
			vectorLock.unlock();
		}
	}
	flag = true;
	close(socketfd);		
	
	fileWatcherThread.join();
  	return 0;
}
