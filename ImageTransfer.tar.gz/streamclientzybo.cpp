#include <sys/socket.h>
#include <sys/signal.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <iostream>
#include <errno.h>
#include <unistd.h>
#include <random>
#include <string>
#include <string.h>
#include <netdb.h>
#include <thread>
#include <chrono>

using namespace std;

int main(int argc, char *argv[]){
	string host = "192.168.56.1";
  	string port = "4000";
	string fileDirectory = ".";
	random_device rd;
	random_device rd2;
	mt19937 width(rd());
	mt19937 grayvalue(rd2());
	uniform_int_distribution<> dimension(200,255);
	uniform_int_distribution<> grayscale(0,255);
	string milli;

  	if(argc > 4){
    		cout << "Invalid input" << "\n";
    		return -1;
  	}

  	if(argc == 4){
		milli = argv[1];
    		host = argv[2];
    		port = argv[3];
  	}

	if(argc == 2){
		milli = argv[1];
	}

  	int socketfd;
  	struct addrinfo hints, *servinfo, *p;

	memset(&hints,0,sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;

	if(getaddrinfo(host.c_str(),port.c_str(),&hints,&servinfo) != 0){
		cout << strerror(errno) << "\n";
		return -1;	
	}
  	
  	struct sockaddr serverAddress;
	for(p = servinfo; p != NULL; p = p->ai_next){
		if((socketfd = socket(p->ai_family,p->ai_socktype,p->ai_protocol)) == -1){
			continue;
		}
		
		if(connect(socketfd,p->ai_addr,p->ai_addrlen) == -1){
			close(socketfd);
			cout << strerror(errno);
			continue;
		}
		break;
	}

	if(p == NULL){
		cout << "Failed to connect: " << host << "\n";
		return -1;
	}
	
	//memcpy(&serverAddress,p->ai_addr,p->ai_addrlen);
	//socklen_t servAddrSize = sizeof(serverAddress);
	freeaddrinfo(servinfo);

	signal(SIGPIPE,SIG_IGN);
	int count = 0;
	cout << "connected" << "\n";
	unsigned char packet[128];
	int totalSend = 1;
	while(true){
		int chooseHeight = 32;
		int randWidth = dimension(width);
		for(int i = 0; i < randWidth; i++){
			unsigned char gray = (unsigned char)grayscale(grayvalue);
			for(int j = 0; j < chooseHeight; j++){
				packet[count] = gray;
				count++;
				if(count == 128){
					int bytesWritten = 0;
					int bytesToWrite = 128;
					//cout << (int) packet[0] << "\n";
					while(bytesToWrite > 0){
						if((bytesWritten = write(socketfd,packet,128)) < 0){
							cout << strerror(errno) << "\n";
							return -1;
							//break;
						}
						bytesToWrite -= bytesWritten;
					}
					count = 0;
					memset(packet,0,128);
				}
			}		
		}
		//Send Termination and dimension
		for(int i = 0; i < 6; i++){
			if(i == 4){
				int test = randWidth;
				packet[count] = (unsigned char)test;
				//cout << (int)packet[count] << "\n";
			}else if(i == 5){
				packet[count] = (unsigned char)chooseHeight;
			}else if(i == 0){
				packet[count] = (unsigned char)'s';
			}else if(i == 1){
				packet[count] = (unsigned char)'t';
			}else if(i == 2){
				packet[count] = (unsigned char)'o';
			}else if(i == 3){
				packet[count] = (unsigned char)'p';
			}

			count++;
			if(count == 128){
				int bytesWritten = 0;
				int bytesToWrite = 128;
				while(bytesToWrite > 0){
					if((bytesWritten = write(socketfd,packet,128)) < 0){
						cout << strerror(errno) << "\n";
						return -1;
						//break;
					}
					bytesToWrite -= bytesWritten;
				}
				count = 0;
				memset(packet,0,128);
			}

		}
		cout << "Sent: " << totalSend << "\n";
		cout << "Thread sleep for " << milli << " ms" "\n";
		totalSend++;
		this_thread::sleep_for(chrono::milliseconds(atoi(milli.c_str())));
		
	}
	close(socketfd);
	return 0;
}
