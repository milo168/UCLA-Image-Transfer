#include <sys/socket.h>
#include <sys/signal.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <iostream>
#include <errno.h>
#include <unistd.h>
#include <random>
#include <string>
#include <string.h>
#include <netdb.h>
#include <thread>
#include <chrono>

using namespace std;

int main(int argc, char *argv[]){
	string host = "192.168.56.1";
  	string port = "4000";
	string fileDirectory = ".";
	srand(time(NULL));
	string milli ="10000";

  	if(argc > 4){
    		cout << "Invalid input" << "\n";
    		return -1;
  	}

  	if(argc == 4){
		milli = argv[1];
    		host = argv[2];
    		port = argv[3];
  	}

	if(argc == 2){
		milli = argv[1];
	}

  	int socketfd;
  	struct addrinfo hints, *servinfo, *p;

	memset(&hints,0,sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;

	if(getaddrinfo(host.c_str(),port.c_str(),&hints,&servinfo) != 0){
		cout << strerror(errno) << "\n";
		return -1;	
	}
  	
  	struct sockaddr serverAddress;
	for(p = servinfo; p != NULL; p = p->ai_next){
		if((socketfd = socket(p->ai_family,p->ai_socktype,p->ai_protocol)) == -1){
			continue;
		}
		
		if(connect(socketfd,p->ai_addr,p->ai_addrlen) == -1){
			close(socketfd);
			cout << strerror(errno);
			continue;
		}
		break;
	}

	if(p == NULL){
		cout << "Failed to connect: " << host << "\n";
		return -1;
	}
	
	//memcpy(&serverAddress,p->ai_addr,p->ai_addrlen);
	//socklen_t servAddrSize = sizeof(serverAddress);
	freeaddrinfo(servinfo);

	signal(SIGPIPE,SIG_IGN);
	int count = 0;
	cout << "connected" << "\n";
	int size = 128;
	unsigned char packet[size];
	int totalSend = 1;
	int slide = 1;

	while(true){
		int chooseHeight = 32;
		int randWidth = 200 + rand() % 55;
		for(int i = 0; i < randWidth; i++){
			//unsigned char gray = (rgb + totalSend) % 256;//(unsigned char)rand() % 256;
			//unsigned char gray = (unsigned char)rand() % 256;
			//unsigned char gray = i;
			slide = 1;
			for(int j = 0; j < chooseHeight; j++){
				unsigned char gray = (unsigned char)((slide + totalSend) % 128);//(unsigned char)rand() % 256;
				packet[count] = gray;
				count++;
				if(count == size){
					int bytesWritten = 0;
					int bytesToWrite = size;
					//cout << (int) packet[0] << "\n";
					while(bytesToWrite > 0){
						if((bytesWritten = write(socketfd,packet,size)) < 0){
							cout << strerror(errno) << "\n";
							return -1;
							//break;
						}
						bytesToWrite -= bytesWritten;
					}
					count = 0;
					memset(packet,0,size);
				}
				slide = slide + 4;
			}
			//rgb++;
			//if(rgb % 256 == 0){
			//	rgb = 0;
			//}
		}
		//Send Termination and dimension
		for(int i = 0; i < 7; i++){
			if(i == 0){
				if(randWidth > 255){
					int test = randWidth;
					packet[count] = (unsigned char)(test >> 8);
				}else{
					int test2 = 0;
					packet[count] = (unsigned char)test2;
				}
				//cout << randWidth << "\n";
			}else if(i == 1){
				int test3 = randWidth;
				packet[count] = (unsigned char)test3;
			}else if(i == 2){
				packet[count] = (unsigned char)chooseHeight;
			}else if(i == 3){
				packet[count] = (unsigned char)'s';
			}else if(i == 4){
				packet[count] = (unsigned char)'t';
			}else if(i == 5){
				packet[count] = (unsigned char)'o';
			}else if(i == 6){
				packet[count] = (unsigned char)'p';
			}

			count++;
			if(count == size){
				int bytesWritten = 0;
				int bytesToWrite = size;
				while(bytesToWrite > 0){
					if((bytesWritten = write(socketfd,packet,size)) < 0){
						cout << strerror(errno) << "\n";
						return -1;
						//break;
					}
					bytesToWrite -= bytesWritten;
				}
				count = 0;
				memset(packet,0,size);
			}

		}
		cout << "Sent: " << totalSend << "\n";
		cout << "Thread sleep for " << milli << " ms" "\n";
		totalSend++;
		this_thread::sleep_for(chrono::milliseconds(atoi(milli.c_str())));
		
	}
	close(socketfd);
	return 0;
}
